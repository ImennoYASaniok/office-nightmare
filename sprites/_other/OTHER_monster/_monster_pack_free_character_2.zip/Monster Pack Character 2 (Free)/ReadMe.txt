Thank you for downloading the pack!

If you liked this pack you might be interested in my upcoming projects.

---------------------------------------------------------------------------------------
CHARACTER CREATOR
---------------------------------------------------------------------------------------

I am currently working on a character creator where you will be able to equip hundreds 
of items, it will have more animations such as more death animations, bow animations, 
staff animations, gun animations, and more. The software is in development and is accessible to Patrons. A public version will be released in the future!

Lots of updates are planned!

You can learn more about it here: https://www.patreon.com/posts/97369386


---------------------------------------------------------------------------------------
RIDDLE ZEN
---------------------------------------------------------------------------------------

I also encourage you to try my free app:
- ANDROID: https://play.google.com/store/apps/details?id=com.AdmurinArts.RiddleZen
- OUTDATED DEMO: https://admurin.itch.io/riddle-zen

You can also check out the Kickstarter over here:
- https://www.kickstarter.com/projects/admurin/riddle-zen
- The kickstarter will allow me to release the game on IOS!

In Riddle Zen you solve riddles and earn plants, it can be played offline and 
is an amazing game for all ages.
